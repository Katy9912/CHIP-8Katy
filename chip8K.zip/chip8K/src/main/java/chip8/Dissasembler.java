package chip8;

public class Dissasembler {
  // private short pc;

    public String pcAddr(byte msb, byte lsb) {
        return String.format("%02X%02X: ", msb, lsb);

    }
    /**
     * msb = most significant byte
     * lsb = less '' ''
     */



    public String sys(byte msb, byte lsb){ /* 0nnn - SYS addr */
        //var addr = ((msb & 0x0F) << 8) | lsb;
        var x = msb & 0x0F;
        return String.format("SYS %02X%02X", x, lsb);
    }

    public String cls(byte msb, byte lsb) {
        return "CLS";
    }

    public String ret(byte msb, byte lsb){
        return "RET";
    }

    public String jp(byte msb, byte lsb) { /* 1nnn - JP addr */
        var x = msb & 0x0F;
        return String.format("JP %02X%02X", x, lsb);
    }
    
    public String call(byte msb, byte lsb) { 
        var x = msb & 0x0F;
       return String.format("CALL %02X%02X", x, lsb); //2nnn - CALL addr
    }

    public String se_xb(byte msb, byte lsb){/* 3xkk - SE Vx, byte */
        var x = msb & 0x0F;

        return String.format("SE V%1X, %02X", x, lsb);
    }

    public String sne_xb(byte msb, byte lsb){  /** SNE 4xkk - SNE Vx, byte */
        var x = msb & 0x0F;

        return String.format("SNE V%1X, %02X", x, lsb);
    } 
  
    public String se_xy(byte msb, byte lsb){ /* 5xy0 - SE Vx, Vy */
        var x = msb & 0x0F;
        var y = (lsb >>> 4) & 0x0F;
        
        return String.format("SE V%1X, V%1X", x, y);
    }

    public String ld_xb(byte msb, byte lsb){ /* 6xkk - LD Vx, byte */
        var x = msb & 0x0F;

        return String.format("LD V%1X, %02X", x, lsb);
    }   

    public String add_xb(byte msb, byte lsb){ /* 7xkk - ADD Vx, byte */
        var x = msb & 0x0F;

        return String.format("ADD V%1X, %02X",x, lsb);
    }

    public String ld_xy(byte msb, byte lsb){  /* 8xy0 - LD Vx, Vy */
        var x = msb & 0x0F;
        var y = (lsb >>> 4) & 0x0F;

        return String.format("LD V%1X, V%1X", x, y);
    }

    public String or_xy(byte msb, byte lsb){  /* 8xy1 - OR Vx, Vy */
        var x = msb & 0x0F;
        var y = (lsb >>> 4) & 0x0F;

        return String.format("OR V%1X, V%1X", x, y);
    }

    public String and_xy(byte msb, byte lsb){  /* 8xy2 - AND Vx, Vy */
        var x = msb & 0x0F;
        var y = (lsb >>> 4) & 0x0F;

        return String.format("AND V%1X, V%1X", x, y);
    }

    public String xor_xy(byte msb, byte lsb){  /* 8xy3 - XOR Vx, Vy */
        var x = msb & 0x0F;
        var y = (lsb >>> 4) & 0x0F;

        return String.format("XOR V%1X, V%1X", x, y);

    } 

    public String add_xy(byte msb, byte lsb){  /* 8xy4 - ADD Vx, Vy */
         var x = msb & 0x0F;
         var y = (lsb >>> 4) & 0x0F;

        return String.format("ADD V%1X, V%1X", x, y);

    }

    public String sub_xy(byte msb, byte lsb){  /* 8xy5 - SUB Vx, Vy */
        var x = msb & 0x0F;
        var y = (lsb >>> 4) & 0x0F;

        return String.format("SUB V%1X, V%1X", x, y);

   }
  
   public String shr_x(byte msb, byte lsb){  /* 8xy6 - SHR Vx {, Vy}*/
    var x = msb & 0x0F;
    //var y = (lsb >>> 4) & 0x0F;

        return String.format("SHR V%1X", x);
}

   public String subn_xy(byte msb, byte lsb){  /* 8xy7 - SUBN Vx, Vy */
    var x = msb & 0x0F;
    var y = (lsb >>> 4) & 0x0F;

        return String.format("SUBN V%1X, V%1X", x, y);

}

public String shl_x(byte msb, byte lsb){  /* 8xyE - SHL Vx {, Vy}*/
    var x = msb & 0x0F;
   // var y = (lsb >>> 4) & 0x0F;

        return String.format("SHL V%1X", x);
}

public String sne_xy(byte msb, byte lsb){  /* 9xy0 - SNE Vx, Vy */
    var x = msb & 0x0F;
    var y = (lsb >>> 4) & 0x0F;

        return String.format("SNE V%1X, V%1X", x, y);

}

public String ld_i(byte msb, byte lsb) { /* Annn - LD I, addr */
    var x = msb & 0x0F;

        return String.format("LD I %02X%02X", x, lsb);
}

public String jp_v0(byte msb, byte lsb) { /* Bnnn - JP V0, addr */
    var x = msb & 0x0F;

        return String.format("JP V0 %02X%02X", x, lsb);
}

public String rnd_xb(byte msb, byte lsb){ /* Cxkk - RND Vx, byte */
    var x = msb & 0x0F;

        return String.format("RND V%1X, %02X",x, lsb);
}

public String drw(byte msb, byte lsb) {  /* Dxyn - DRW Vx, Vy, nibble */
    var x = msb & 0x0F;
    var n = lsb & 0x0F;
    var y = (lsb >>> 4) & 0x0F;
        return String.format("DRW V%1X, V%1X, %1X", x, y, n);
}

public String skp_x(byte msb, byte lsb){ /* Ex9E - SKP Vx */
    var x = msb & 0x0F;

        return String.format("SKP V%1X, %02X", x);
}

public String sknp_x(byte msb, byte lsb){ /* ExA1 - SKNP Vx */
    var x = msb & 0x0F;

        return String.format("SKNP V%1X", x);
}

public String ld_xdt(byte msb, byte lsb){ /* Fx07 - LD Vx, DT */
    var x = msb & 0x0F;

        return String.format("LD V%1X, DT", x);
}

public String ld_xk(byte msb, byte lsb){ /* Fx0A - LD Vx, K */
    var x = msb & 0x0F;

        return String.format("LD V%1X, K", x);
}

public String ld_dt(byte msb, byte lsb){ /* Fx15 - LD DT, Vx */
    var x = msb & 0x0F;

        return String.format("LD DT, V%1X", x);
}

public String ld_st(byte msb, byte lsb){ /* Fx18 - LD ST, Vx */
    var x = msb & 0x0F;

        return String.format("LD ST, V%1X", x);
}

public String add_i(byte msb, byte lsb){ /* Fx1E - ADD I, Vx */
    var x = msb & 0x0F;

        return String.format("ADD I, V%1X", x);
}

public String ld_f(byte msb, byte lsb){ /* Fx29 - LD F, Vx */
    var x = msb & 0x0F;

        return String.format("LD F, V%1X", x);
}

public String ld_b(byte msb, byte lsb){ /* Fx33 - LD B, Vx */
    var x = msb & 0x0F;

        return String.format("LD B, V%1X", x);
}

public String ldi(byte msb, byte lsb){ /* Fx55 - LD [I], Vx */
    var x = msb & 0x0F;

        return String.format("LD [I], V%1X", x);
}

public String ld_xi(byte msb, byte lsb){ /* Fx65 - LD Vx, [I] */
    var x = msb & 0x0F;

        return String.format("LD V%1X, [I]", x);
}

}
