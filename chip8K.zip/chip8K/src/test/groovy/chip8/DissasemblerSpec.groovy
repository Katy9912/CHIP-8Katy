package chip8

import spock.lang.Specification

class DissasemblerSpec extends Specification {
    
    def "Clear Screen is printed"() {
        setup:
        def app = new Dissasembler()

        when:
        def result = app.cls()

        then:
        result == "0000: CLS"
    }

    def "Return is printed"() {
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ret()

        then:
        result == "0000: RET"
    }

    def "SYS is decoded"() {
        setup:
        def app = new Dissasembler()

        when:
        def result = app.sys((byte)0x3E, (byte)0x54)

        then:
        result == "0000: SYS 0E54"
    }

    
    /*def "CLS is declared"(){
        setup: 
        def app = new Dissasembler()

        when:
        def result = app.cls((byte)0x00, (byte)0x00)
    }*/
    def "JP is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.jp((byte)0x13, (byte)0x54)

        then:
        result == "0000: JP 0354" // ¿Porqué no 13?
    }

    def "CALL is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.call((byte)0x13, (byte)0x54)

        then:
        result == "0000: CALL 0354" 
    }

    def "SE is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.se_xb((byte)0x3E, (byte)0x54)

        then:
        result == "0000: SE VE, 54" // ¿Porqué VE, 54?
    }

    def "SNE is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.sne_xb((byte)0x4E, (byte)0x54)

        then:
        result == "0000: SNE VE, 54" 
    }

    def "SE is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.se_xy((byte)0x5E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: SE VE, V5" // ¿Porqué VE, 54?
    }

def "LD is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_xb((byte)0x6E, (byte)0x54)

        then:
        result == "0000: LD VE, 54" 
    }

def "ADD is declared"(){
    setup:
    def app = new Dissasembler()

    when:
    def result = app.add_xb((byte)0x7E, (byte)0x54)

    then:
    result == "0000: ADD VE, 54"
}

def "LD is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD VE, V5" // ¿Porqué VE, 54?
    }

def "OR is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.or_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: OR VE, V5" // ¿Porqué VE, 54?
    }

def "AND is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.and_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: AND VE, V5" // ¿Porqué VE, 54?
    }

def "XOR is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.xor_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: XOR VE, V5" // ¿Porqué VE, 54?
    }

def "ADD is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.add_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: ADD VE, V5" // ¿Porqué VE, 54?
    }

def "SUB is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.sub_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: SUB VE, V5" // ¿Porqué VE, 54?
    }

def "SHR is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.shr_x((byte)0x8E, (byte)0x54)

        then:
        result == "0000: SHR VE {, V5}" // ¿Porqué VE, 54?         //"SHR V%1X {, V%1X}"
    }

def "SUBN is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.subn_xy((byte)0x8E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: SUBN VE, V5" // ¿Porqué VE, 54?
    }

def "SHL is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.shl_x((byte)0x8E, (byte)0x54)

        then:
        result == "0000: SHL VE {, V5}" // ¿Porqué VE, 54? //SHL V%1X {, V%1X}
    }

def "SNE is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.sne_xy((byte)0x9E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: SNE VE, V5" // ¿Porqué VE, 54?
    }

 def "LD I is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_i((byte)0xAE, (byte)0x54)

        then:
        result == "0000: LD I" // ¿Porqué no 13? //LD I, %04X", addr
    }

def "JP V0 is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.jp_v0((byte)0xBE, (byte)0x54)

        then:
        result == "0000: JP V0" // ¿Porqué no 13?
    }

def "RND is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.rnd_xb((byte)0xCE, (byte)0x54)

        then:
        result == "0000: RND VE, 54" // ¿Porqué VE, 54?
    }


def "DRW is declared"(){
    setup: 
    def app = new Dissasembler()

    when:
    def result = app.drw((byte)0xDE, (byte)0x54)

    then:
    result == "0000: DRW VE, V5, 4"
}


def "SKP is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.skp_x((byte)0xEE, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: SKP VE, 54" // ¿Porqué VE, 54?
    }

def "SKNP is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.sknp_x((byte)0xEE, (byte)0X54) // ¿Porqué 0x05E?

        then:
        result == "0000: SKNP VE, 54" // ¿Porqué VE, 54?
    }

def "LD is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_xdt((byte)0xFE, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD VE, DT" // ¿Porqué VE, 54?  //LD V%1X, DT 
    }

 def "LD is decoded"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_xk((byte)0xFE, (byte)0x54)

        then:
        result == "0000: LD VE, K"
    }

def "LD DT is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_dt((byte)0xFE, (byte)0X54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD DT, VE" // ¿Porqué VE, 54?
    }

def "LD ST is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_st((byte)0xFE, (byte)0X54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD ST, VE" // ¿Porqué VE, 54?
    }

def "ADD I is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.add_i((byte)0xFE, (byte)0X54) // ¿Porqué 0x05E?

        then:
        result == "0000: ADD I, VE" // ¿Porqué VE, 54?
    }

    def "LD F is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_f((byte)0xFE, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD F, VE" // ¿Porqué VE, 54?
    }

    def "LD B is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_b((byte)0x5E, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD B, VE" // ¿Porqué VE, 54?
    }

    def "LD [I] is declared"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ldi((byte)0xFE, (byte)0x54) // ¿Porqué 0x05E?

        then:
        result == "0000: LD [I], VE" // ¿Porqué VE, 54?
    }

    def "LD is decoded"(){
        setup:
        def app = new Dissasembler()

        when:
        def result = app.ld_xi((byte)0xFE, (byte)0x54)

        then:
        result == "0000: LD VE, [I]"
    }

} 
